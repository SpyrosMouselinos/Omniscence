from Omniscence.Data_analysis import OmniAnalyzer
